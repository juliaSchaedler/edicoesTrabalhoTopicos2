from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class QuantidadePessoas(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    dia = db.Column(db.Date, nullable=False)
    quantidade = db.Column(db.Integer, nullable=False)

class CafeConsumido(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    dia = db.Column(db.Date, nullable=False)
    quantidade = db.Column(db.Integer, nullable=False)

class LampadasLigadas(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    dia = db.Column(db.Date, nullable=False)
    quantidade = db.Column(db.Integer, nullable=False)  

class ComputadoresLigados(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    dia = db.Column(db.Date, nullable=False)
    quantidade = db.Column(db.Integer, nullable=False)  

class EnergiaConsumida(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    dia = db.Column(db.Date, nullable=False)
    quantidade = db.Column(db.Integer, nullable=False)  
