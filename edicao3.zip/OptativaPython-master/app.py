from flask import Flask, render_template, request
from models import db, QuantidadePessoas, CafeConsumido, LampadasLigadas, ComputadoresLigados, EnergiaConsumida
from datetime import datetime
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import io
import base64

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False  # Para evitar um aviso
app.secret_key = 'alguma_chave_secreta_aqui'

db.init_app(app)

def criarGrafico(qtd, dias, nomeGrafico, labelX,labelY):
    plt.cla()
    plt.clf()
    plt.plot(dias, qtd)
    plt.title(nomeGrafico)
    plt.xlabel(labelX)
    plt.ylabel(labelY)

    img = io.BytesIO()
    plt.savefig(img, format='png')
    img.seek(0)

    # Convert BytesIO object to base64 string
    img_b64 = base64.b64encode(img.getvalue()).decode()

    return img_b64


def exibirPessoas():
    dadosPessoas = QuantidadePessoas.query.order_by(QuantidadePessoas.dia.desc()).limit(7).all()
    mediaPessoas = 0
    pessoasQuantidade = []
    pessoasDia = []
    for item in dadosPessoas:
        pessoasQuantidade.append(item.quantidade)
        pessoasDia.append(item.dia.strftime("%d/%m"))
        mediaPessoas +=item.quantidade

    pessoasQuantidade.reverse()
    pessoasDia.reverse()

    if(len(dadosPessoas)!=0):
        mediaPessoas = mediaPessoas/len(dadosPessoas)

    imgPessoas = criarGrafico(nomeGrafico="Pessoas Trabalhando x Dias", labelX="Dias", labelY="Quantidade Pessoas", qtd = pessoasQuantidade, dias = pessoasDia)

    return mediaPessoas, imgPessoas

def exibirCafe():
    dadosCafe = CafeConsumido.query.order_by(CafeConsumido.dia.desc()).limit(7).all()
    mediaCafe = 0
    cafeQuantidade = []
    cafeDia = []
    for item in dadosCafe: 
        mediaCafe +=item.quantidade
        cafeQuantidade.append(item.quantidade)
        cafeDia.append(item.dia.strftime("%d/%m"))

    cafeQuantidade.reverse()
    cafeDia.reverse()

    if(len(dadosCafe)!=0):
        mediaCafe = mediaCafe/len(dadosCafe)

    imgCafe = criarGrafico(nomeGrafico = "Café Consumido x Dias", labelX="Dias", labelY="Café Consumido(ml)", qtd = cafeQuantidade, dias = cafeDia)

    return mediaCafe, imgCafe

def exibirLampadas():
    dadosLampadas = LampadasLigadas.query.order_by(LampadasLigadas.dia.desc()).limit(7).all()
    mediaLampadas = 0
    lampadasQuantidade= []
    lampadasDia = []
    for item in dadosLampadas: 
        mediaLampadas +=item.quantidade
        lampadasQuantidade.append(item.quantidade)
        lampadasDia.append(item.dia.strftime("%d/%m"))

    lampadasQuantidade.reverse()
    lampadasDia.reverse()

    if(len(dadosLampadas)!=0):
        mediaLampadas = mediaLampadas/len(dadosLampadas)

    imgLampadas = criarGrafico(nomeGrafico = "Lâmpadas Ligadas x Dias", labelX="Dias", labelY="Lâmpadas Ligadas", qtd = lampadasQuantidade, dias = lampadasDia)

    return mediaLampadas, imgLampadas

def exibirComputadores(): 
    dadosComputadores = ComputadoresLigados.query.order_by(ComputadoresLigados.dia.desc()).limit(7).all()
    mediaComputadores = 0
    computadoresQuantidade = []
    computadoresDia = []
    for item in dadosComputadores: 
        mediaComputadores +=item.quantidade
        computadoresQuantidade.append(item.quantidade)
        computadoresDia.append(item.dia.strftime("%d/%m"))

    computadoresQuantidade.reverse()
    computadoresDia.reverse()

    if(len(dadosComputadores)!=0):
        mediaComputadores = mediaComputadores/len(dadosComputadores)

    imgComputadores = criarGrafico(nomeGrafico = "Computadores Ligados x Dias", labelX="Dias", labelY="Computadores Ligados", qtd = computadoresQuantidade, dias = computadoresDia)

    return mediaComputadores, imgComputadores

def exibirEnergia():
    dadosEnergia = EnergiaConsumida.query.order_by(EnergiaConsumida.dia.desc()).limit(7).all()
    mediaEnergia = 0
    energiaQuantidade = []
    energiaDia = []
    for item in dadosEnergia: 
        mediaEnergia +=item.quantidade
        energiaQuantidade.append(item.quantidade)
        energiaDia.append(item.dia.strftime("%d/%m"))

    energiaQuantidade.reverse()
    energiaDia.reverse()

    if(len(dadosEnergia)!=0):
        mediaEnergia = mediaEnergia/len(dadosEnergia)

    imgEnergia = criarGrafico(nomeGrafico = "Energia Consumida x Dias", labelX="Dias", labelY="Energia Consumida(kw)", qtd = energiaQuantidade, dias = energiaDia)

    return mediaEnergia, imgEnergia

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/inserirDados')
def inserirDados():
    return render_template('inserir_dados.html')

@app.route('/salvarDadosPessoas', methods=['POST'])
def salvarDadosPessoas():
    date = datetime.strptime(request.form.get('date'), "%Y-%m-%d").date()
    pessoas = int(request.form.get('pessoas'))
    nova_entrada = QuantidadePessoas(dia=date, quantidade=pessoas)
    db.session.add(nova_entrada)
    db.session.commit()

    return render_template('inserir_dados.html')

@app.route('/salvarDadosCafe', methods=['POST'])
def salvarDadosCafe():
    date = datetime.strptime(request.form.get('date'), "%Y-%m-%d").date()
    pessoas = int(request.form.get('cafe'))
    nova_entrada = CafeConsumido(dia=date, quantidade=pessoas)
    db.session.add(nova_entrada)
    db.session.commit()

    return render_template('inserir_dados.html')

@app.route('/salvarDadosLampadas', methods=['POST'])
def salvarDadosLampadas():
    date = datetime.strptime(request.form.get('date'), "%Y-%m-%d").date()
    pessoas = int(request.form.get('lampadas'))
    nova_entrada = LampadasLigadas(dia=date, quantidade=pessoas)
    db.session.add(nova_entrada)
    db.session.commit()

    return render_template('inserir_dados.html')

@app.route('/salvarDadosComputadores', methods=['POST'])
def salvarDadosComputadores():
    date = datetime.strptime(request.form.get('date'), "%Y-%m-%d").date()
    pessoas = int(request.form.get('computadores'))
    nova_entrada = ComputadoresLigados(dia=date, quantidade=pessoas)
    db.session.add(nova_entrada)
    db.session.commit()

    return render_template('inserir_dados.html')

@app.route('/salvarDadosEnergia', methods=['POST'])
def salvarDadosEnergia():
    date = datetime.strptime(request.form.get('date'), "%Y-%m-%d").date()
    pessoas = int(request.form.get('energia'))
    nova_entrada = EnergiaConsumida(dia=date, quantidade=pessoas)
    db.session.add(nova_entrada)
    db.session.commit()

    return render_template('inserir_dados.html')

@app.route('/verDados')
def ver_dados():
    mediaPessoas, imgPessoas = exibirPessoas()
    mediaCafe, imgCafe = exibirCafe()
    mediaLampadas, imgLampadas = exibirLampadas()
    mediaComputadores, imgComputadores = exibirComputadores()
    mediaEnergia, imgEnergia = exibirEnergia()

    return render_template('ver_resultados.html', imgPessoas = imgPessoas, mediaPessoas = mediaPessoas,
    imgCafe = imgCafe, mediaCafe=mediaCafe,
    imgLampadas = imgLampadas, mediaLampadas = mediaLampadas,
    imgComputadores = imgComputadores, mediaComputadores=mediaComputadores,
    imgEnergia = imgEnergia, mediaEnergia = mediaEnergia)

with app.app_context():
   db.create_all()

if __name__ == '__main__':
    app.run(debug=True)
